// HeroSection.tsx
// Minimal, alive, but quiet.
// Uses three muted hues only: slate-50, slate-900, and teal-600.

import { ArrowRight } from "lucide-react";

const HeroSection = () => (
  <section className="grid md:grid-cols-2 gap-10 md:gap-20 items-center py-44 px-6 max-w-6xl mx-auto">
    {/* Left */}
    <div className="space-y-6">
      <h1 className="text-5xl text-center md:text-left md:text-5xl font-medium leading-tight text-slate-900">
        Kianmehr Mezhlugue
        <br />
        <span className="text-teal-600">Operations</span>
      </h1>

      <p className="text-slate-600 max-w-md">
        Business administration that feels like second nature. Clear, calm, and
        built for ambitious teams who prefer to skip the noise.
      </p>

      <div className="flex items-center gap-6 text-sm text-slate-500">
        <span>4.9 / 5 from 500+ teams</span>
        <span>•</span>
        <span>5 000+ active users</span>
      </div>

      <button className="inline-flex items-center gap-2 px-5 py-2.5 bg-teal-600 text-white rounded-md text-sm font-medium hover:bg-teal-700 transition-colors">
        Hire Me
        <ArrowRight size={16} />
      </button>
    </div>

    {/* Right – single, living card */}
    <div className="relative">
      {/* faint animated glow */}
      <div className="absolute inset-0 rounded-xl bg-teal-400/10 blur-2xl animate-pulse" />
      <div className="relative bg-white/70 backdrop-blur border border-slate-200 rounded-xl p-6 shadow-sm">
        <div className="text-sm font-medium text-slate-900 mb-4">Dashboard</div>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-xl font-semibold text-teal-600">$84.2K</div>
            <div className="text-xs text-slate-500">Revenue</div>
          </div>
          <div>
            <div className="text-xl font-semibold text-slate-700">$42.7K</div>
            <div className="text-xs text-slate-500">Expenses</div>
          </div>
          <div>
            <div className="text-xl font-semibold text-slate-700">$41.5K</div>
            <div className="text-xs text-slate-500">Profit</div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default HeroSection;
