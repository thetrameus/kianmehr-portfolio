// ContactFooter.tsx
// Contact + glass ribbon footer with depth, blur & floating elements

import React, { useState } from "react";
import { Mail, Phone, MapPin, ArrowRight } from "lucide-react";

export default function ContactFooter() {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-sky-50 via-white to-cyan-50">
      {/* CONTACT */}
      <div className="max-w-5xl mx-auto px-6 py-24">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-light text-sky-800">Let’s talk</h2>
          <p className="text-sm text-sky-600 mt-1">
            Quietly build something good together.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row items-center justify-center gap-12">
          {/* contact rings */}
          <div className="space-y-8">
            {[
              {
                icon: Mail,
                text: "hello@kianmehr.com",
                href: "mailto:hello@kianmehr.com",
              },
              {
                icon: Phone,
                text: "+1 (415) 555-0144",
                href: "tel:+14155550144",
              },
              { icon: MapPin, text: "San Francisco, CA" },
            ].map((item, i) => (
              <a
                key={i}
                href={item.href}
                className="flex items-center gap-4 p-3 rounded-lg bg-white/30 backdrop-blur-sm border border-white/40 hover:bg-white/50 transition"
              >
                <div className="w-10 h-10 flex items-center justify-center bg-sky-600 rounded-full text-white shadow-md">
                  <item.icon size={16} />
                </div>
                <span className="text-sm text-sky-800">{item.text}</span>
              </a>
            ))}
          </div>

          {/* glass form */}
          <form
            onSubmit={handleSubmit}
            className="w-full max-w-sm p-8 bg-white/40 backdrop-blur-md border border-white/50 rounded-3xl shadow-xl space-y-4"
          >
            <input
              type="text"
              placeholder="Name"
              required
              className="w-full px-4 py-2 bg-white/60 border border-white/60 rounded-lg text-sm focus:ring-2 focus:ring-sky-400 outline-none"
            />
            <input
              type="email"
              placeholder="Email"
              required
              className="w-full px-4 py-2 bg-white/60 border border-white/60 rounded-lg text-sm focus:ring-2 focus:ring-sky-400 outline-none"
            />
            <textarea
              rows={3}
              placeholder="Message"
              required
              className="w-full px-4 py-2 bg-white/60 border border-white/60 rounded-lg text-sm resize-none focus:ring-2 focus:ring-sky-400 outline-none"
            />
            <button
              type="submit"
              className={`w-full flex items-center justify-center gap-2 py-2 rounded-lg text-sm transition-all duration-300 ${
                sent
                  ? "bg-sky-600 text-white"
                  : "bg-sky-600/80 text-white hover:bg-sky-700 hover:shadow-lg"
              }`}
            >
              {sent ? "Sent ✓" : "Send"}
              {!sent && <ArrowRight size={14} />}
            </button>
          </form>
        </div>
      </div>

      {/* GLASS FOOTER — elementful, blurred, floating */}
      <footer className="relative">
        {/* backdrop blur layer */}
        <div className="absolute inset-0 bg-white/30 backdrop-blur-lg" />

        <div className="relative max-w-7xl mx-auto px-6 py-12">
          {/* floating glass ribbon */}
          <div className="flex flex-col lg:flex-row justify-between items-center gap-8">
            {/* left: mini-grid */}
            <div className="flex gap-6 text-xs">
              {["Privacy", "Terms", "Cookies", "Status"].map((l) => (
                <a
                  key={l}
                  href="#"
                  className="text-sky-800 hover:text-sky-600 transition"
                >
                  {l}
                </a>
              ))}
            </div>

            {/* center: floating circles */}
            <div className="flex gap-4">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className="w-10 h-10 bg-white/40 backdrop-blur-sm border border-white/50 rounded-full flex items-center justify-center text-sky-700 text-xs font-bold shadow-md"
                >
                  {["©", "K", "M"][i]}
                </div>
              ))}
            </div>

            {/* right: social icons */}
            <div className="flex gap-4">
              {["X", "in", "GH"].map((label) => (
                <a
                  key={label}
                  href="#"
                  className="w-7 h-7 flex items-center justify-center bg-white/40 backdrop-blur-sm border border-white/50 rounded-full text-xs text-sky-800 shadow hover:bg-white/60 transition"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>

          {/* subtle bottom line */}
          <hr className="mt-8 border-white/20" />
          <p className="text-center text-xs text-sky-800/60 mt-4">
            © 2024 Kianmehr — built on calm
          </p>
        </div>
      </footer>
    </section>
  );
}
