// KianmehrBiography.tsx
// Minimal, alive, icy-blue crystal scroll — complete text woven into glass layers

import { useState, useEffect } from "react";
import { Calendar, School, Users, Briefcase, MapPin } from "lucide-react";

const bio = {
  name: "Kianmehr Saeed Afkhamolshora",
  born: "October 31, 2005 · Mashhad",
  summary:
    "Architect’s son, geneticist’s child, swimmer turned content-creator, quietly building calm systems.",
  sections: [
    {
      id: "pool",
      title: "In Water, I Found Flow",
      icon: <Calendar size={20} />,
      image: "./src/assets/swimming.jpg",
      text: `I started swimming at age six under coach Alireza Valizadeh at Kazemian Pool. Teenage water-polo at Gharaman Academy (Tajeddin brothers) shaped team discipline. Later, I trained alone at Foroumandi and 15 Khordad pools. Winter 2025 — Level 3 Swimming Coach certificate under Moshtagh & Valizadeh.`,
      skills: ["Discipline", "Flow states", "Precision"],
    },
    {
      id: "school",
      title: "Classrooms & Corridors",
      icon: <School size={20} />,
      image: "./src/assets/kidding.jpg",
      text: `Omid School (1-6) → Noor Imam Reza (7) → Allameh Tabatabaei (8) → Pazhohesh (9). High-school Humanities at Farhang Dehkhoda, Kavosh, Hosseinnia. Fall 2024 — admitted to Khayyam University of Mashhad, Business Management. Learning became architecture. `,
      skills: ["Curiosity", "Structure", "Humanities lens"],
    },
    {
      id: "language",
      title: "Words that Bridge",
      icon: <Users size={20} />,
      image: "./src/assets/man.jpg",
      text: `English began at Mahan College, deepened at Ariana Institute. Fall 2024 — TTC certification + FCE & CAE. Teaching revealed: clarity is architecture; every word carries weight. Students became first UX testers.`,
      skills: ["Clarity", "Empathy", "Teaching"],
    },
    {
      id: "content",
      title: "Pixels & Projects",
      icon: <Briefcase size={20} />,
      image: "./src/assets/brand.png",
      text: `June 2024 internship at Mammoth Accelerator under Mostafa Mirnejad & Hamid Hamed: Mahestan, Ava Lifestyle, Roya Tarh, SuperFrost, Wonderland, Mellat Park, Champions Complex. December 2024 — independent creator with Kardan, ISB, Qasr Mosaic, Nexio, PakhshoPla, Kash Plus.`,
      skills: ["Storytelling", "Scale", "Quiet growth"],
    },
  ],
};

export default function KianmehrBiography() {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () =>
      setScrollProgress(
        (window.pageYOffset /
          (document.documentElement.scrollHeight - window.innerHeight)) *
          100
      );
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-sky-50 via-white to-cyan-50">
      {/* sky progress */}
      <div className="fixed top-0 left-0 w-full h-1 bg-sky-200 z-50">
        <div
          className="h-full bg-sky-600 transition-all"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Hero */}
      <div className="min-h-screen flex items-center justify-center px-6 text-center space-y-4">
        <div>
          <h1 className="text-5xl font-light text-sky-800">{bio.name}</h1>
          <p className="text-lg text-sky-600">{bio.born}</p>
          <p className="text-sm text-gray-600 max-w-md mx-auto mt-4">
            {bio.summary}
          </p>
        </div>
      </div>

      {/* Glass chapters */}
      <div className="max-w-5xl mx-auto px-6 space-y-32 py-20">
        {bio.sections.map((section, i) => (
          <article
            key={section.id}
            className="grid md:grid-cols-2 gap-8 p-6 bg-white/30 backdrop-blur-md border border-white/40 rounded-3xl shadow-xl"
          >
            {/* image */}
            <div className="relative">
              <img
                src={section.image}
                alt={section.title}
                className="w-full sm:h-[350px] md:h-[300px] rounded-2xl shadow-lg"
              />
              <div className="absolute -top-5 left-5 w-12 h-12 flex items-center justify-center bg-sky-400 text-white rounded-full shadow-md">
                {section.icon}
              </div>
            </div>

            {/* text */}
            <div className="space-y-3">
              <h2 className="text-2xl font-medium text-sky-800">
                {section.title}
              </h2>
              <p className="text-sm text-gray-700 leading-relaxed">
                {section.text}
              </p>
              <div className="flex flex-wrap gap-2">
                {section.skills.map((s) => (
                  <span
                    key={s}
                    className="px-3 py-1 bg-sky-100/50 text-sky-800 text-xs rounded-full"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* crystal outro */}
      <div className="py-16 text-center">
        <h2 className="text-3xl font-light text-sky-800">Quiet synthesis</h2>
        <p className="text-sm text-sky-600 mt-2">
          From pool to pixels — one calm wave at a time.
        </p>
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="mt-6 px-5 py-2 border border-sky-300 rounded-full text-sm text-sky-700 hover:bg-sky-100 transition"
        >
          Back to top
        </button>
      </div>
    </section>
  );
}
