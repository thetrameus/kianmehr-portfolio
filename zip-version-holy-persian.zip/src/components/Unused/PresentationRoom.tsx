import PresentationRoom from "./PresentationRoom";

export default function FinalPresent() {
  return <PresentationRoom />;
}
